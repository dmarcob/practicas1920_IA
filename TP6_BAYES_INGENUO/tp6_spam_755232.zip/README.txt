El fichero load_mails.py es el módulo principal y el que se debe ejecutar.
En este fichero hay que modificar el path para poder leer los mails
correctamente.

El fichero kfolfCrossValidation.py contiene la implementación del algoritmo k-fold
cross-validation, además de la función auxiliar pruebas_laplace.
