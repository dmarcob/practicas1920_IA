package aima.gui.nqueens.csp;

import aima.core.search.csp.Assignment;
import aima.core.search.csp.Variable;
/**
 * 
 * @author Diego Marco, 755232
 *
 */
public class NQueensAssignment extends Assignment {
	public NQueensAssignment() {
		super();
	}
}
